


LaTex - FORMATVORLAGE 
f�r Abschluss- und Seminararbeiten
am Lehrstuhl f�r angewandte Statistik
________________________________________________
________________________________________________



Ordner bzw. Dateien dieser Vorlage
________________________________________________


/Bilder =>alle Bilder/Grafiken der Arbeit hier speichern

/Kapitel =>je Kap. eine Kapitel-Tex-Datei, die Kap. dann hier speichern

/Literatur => enth�lt im Normafall nur "quellen.bib" (Stichwort: BibTex)

/Titel =>enth�lt die Deckblatt-Tex-Datei (Titel,Autor usw.)

vorlage.tex =>daraus wird das PDF-Dokument erstellt (Wurzeldokument)



Wurzeldokument - vorlage.tex
________________________________________________

Unterteilt in Packages und Document

1.Packages
In der Regel sind hier keine �nderungen n�tig!
Die aufgef�hrten Packete m�ssen vorhanden/installiert sein,
damit das PDF fehlerfrei generiert werden kann. 
Um LaTex Packete zu installieren, die kostenlose Software "Miktex" nutzen.

2.Document
Hier werden die Elemente angegeben, aus denen das Dokument am Ende besteht.
Dazu geh�ren beispielsweise Titelblatt, die Kapitel, Abstract, 
Literaturverzeichnis, Inhaltsverzeichnis usw..
Zeilen, die mit einem %-Zeichen beginnen sind Kommentare und werden
vom LaTex-Interpreter nicht ber�cksichtigt.



LaTex Software f�r Windows
________________________________________________

TeXworks - Textverarbeitung in LaTex
(erstellen der PDF Dokumente)

(optionale Software)
Miktex - um zus�tzlich Pakete einzubinden
JabRef - Verwaltung des BibTex Literaturverzeichnisses
